This archive file contains the source code for examples in Beginning Android Application Development 
(ISBN: 978-1118017111). The source code is for your convenience purposes only. The source code is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

The code is organized into various folders, each folder corresponding to a chapter in the book. 
All the code in these folders has been tested with version 2.3 of the Android SDK.

Chapter 1 - Projects provided
Chapter 2 - Projects provided
Chapter 3 - Projects provided
Chapter 4 - Projects provided
Chapter 5 - Projects provided
Chapter 6 - Projects provided
Chapter 7 - Projects provided
Chapter 8 - Projects provided
Chapter 9 - Projects provided
Chapter 10 - Projects provided
Chapter 11 - No code

IMPORTANT NOTE 
--------------------------------------------------------- 
All the examples discussed in this book were written and tested using the Android 2.3 SDK.

While every effort has been made to ensure that the screen shots are as up to date as possible, the actual screen that you see may differ when the Android SDK changes.

Code Examples are available for all chapters (1-10), except Chapter 11.